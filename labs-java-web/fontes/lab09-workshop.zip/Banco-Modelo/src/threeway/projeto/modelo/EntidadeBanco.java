package threeway.projeto.modelo;


public abstract class EntidadeBanco implements Entidade{

	public abstract Long getIdentificador();

}
