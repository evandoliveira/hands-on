package threeway.projeto.modelo.enums;


public enum EnumTipoTransacao {

	SAQUE, DEPOSITO, TRANSFERENCIA;
}
