package threeway.projeto.modelo;

public interface Entidade {

	Long getIdentificador();

}
